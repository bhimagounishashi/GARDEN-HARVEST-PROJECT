import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, StatusBar, Text, View, StyleSheet } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import NetInfo from '@react-native-community/netinfo';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DashboardScreen from './src/screens/DashboardScreen';
import RecordsScreen from './src/screens/RecordsScreen';
import AddHarvestScreen from './src/screens/AddHarvestScreen';
import InsightsScreen from './src/screens/InsightsScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import { useHarvestData } from './src/hooks/useHarvestData';
import { parseHarvestCsv, stringifyHarvestCsv } from './src/utils/csv';
import { logger } from './src/services/logger';

const NAV = [
  {key:'home',label:'Home',icon:'⌂'}, {key:'records',label:'Records',icon:'▤'},
  {key:'add',label:'Add',icon:'+'}, {key:'insights',label:'Insights',icon:'▥'},
  {key:'more',label:'More',icon:'•••'}
];
const demoData = () => {
  const crops=['Tomato','Spinach','Carrot','Potato','Cucumber','Beans','Onion','Brinjal'];
  const categories={Tomato:'Fruit',Spinach:'Leafy',Carrot:'Root',Potato:'Root',Cucumber:'Fruit',Beans:'Other',Onion:'Root',Brinjal:'Fruit'};
  return Array.from({length:40},(_,i)=>{
    const crop=crops[i%crops.length], d=new Date(); d.setDate(d.getDate()-(i%35));
    return {date:d.toISOString().slice(0,10),crop,category:categories[crop],qty:Number((2+Math.random()*28).toFixed(1))};
  });
};

function AppContent() {
  const data=useHarvestData();
  const [tab,setTab]=useState('home');
  const [editing,setEditing]=useState(null);
  const [online,setOnline]=useState(true);
  const [introDone,setIntroDone]=useState(null);
  useEffect(()=>{
    AsyncStorage.getItem('ghr-onboarded').then(v=>setIntroDone(v==='yes')).catch(e=>logger.warn('Could not read onboarding preference',e));
    const unsub=NetInfo.addEventListener(s=>setOnline(!!s.isConnected));
    return unsub;
  },[]);

  const shareFile=async(name,content,mime)=>{
    try{
      const path=`${FileSystem.cacheDirectory}${name}`;
      await FileSystem.writeAsStringAsync(path,content);
      if(await Sharing.isAvailableAsync()) await Sharing.shareAsync(path,{mimeType:mime,dialogTitle:'Garden Harvest Register'});
      else Alert.alert('Export ready',`File saved to ${path}`);
    }catch(e){logger.error('File export failed',e);Alert.alert('Export failed',String(e.message||e));}
  };

  const exportData=async type=>{
    const records=data.records;
    if(type==='csv') return shareFile('garden-harvest.csv',stringifyHarvestCsv(records),'text/csv');
    if(type==='json') return shareFile('garden-harvest.json',JSON.stringify(records,null,2),'application/json');
    const lines=['# Garden Harvest Register Report','','Generated: '+new Date().toISOString(),'','Total records: '+records.length,'Total harvest: '+data.summary.total.toFixed(2)+' kg','','| Date | Crop | Category | Quantity (kg) |','|---|---|---|---:|',...records.map(r=>`| ${r.date} | ${r.crop} | ${r.category} | ${r.qty} |`)];
    return shareFile('garden-harvest-report.md',lines.join('\n'),'text/markdown');
  };

  const importData=async type=>{
    try{
      const result=await DocumentPicker.getDocumentAsync({type:type==='csv'?['text/csv','text/comma-separated-values']:['application/json','text/json'],copyToCacheDirectory:true});
      if(result.canceled)return;
      const text=await FileSystem.readAsStringAsync(result.assets[0].uri);
      let rows=[];
      if(type==='json'){const parsed=JSON.parse(text);if(!Array.isArray(parsed))throw new Error('JSON file must contain an array of records.');rows=parsed;}
      else {const parsed=parseHarvestCsv(text);if(parsed.errors.length)throw new Error(parsed.errors.join('; '));rows=parsed.rows;}
      const outcome=await data.importRecords(rows);
      Alert.alert('Import complete',`${outcome.imported} record(s) imported. ${outcome.errors.length} row(s) skipped.`);
    }catch(e){logger.error('Import failed',e);Alert.alert('Import failed',String(e.message||e));}
  };

  const loadDemo=async()=>{
    const outcome=await data.importRecords(demoData());
    Alert.alert('Demo data',`${outcome.imported} sample records imported.`);
  };
  const clearAll=()=>Alert.alert('Clear all records?','This action cannot be undone.',[
    {text:'Cancel',style:'cancel'},
    {text:'Clear',style:'destructive',onPress:async()=>{const {replaceAllHarvests}=require('./src/data/harvestRepository');await replaceAllHarvests([]);await data.refresh();}}
  ]);

  if(data.loading||introDone===null) return <SafeAreaView style={styles.loading}><ActivityIndicator size="large" color="#28734D"/><Text style={styles.brand}>Garden Harvest Register</Text><Text style={styles.muted}>Preparing your garden dashboard…</Text></SafeAreaView>;
  if(!introDone) return <SafeAreaView style={styles.intro}><Text style={styles.logo}>🌱</Text><Text style={styles.introTitle}>Garden Harvest{"\n"}Register</Text><Text style={styles.introText}>A simple way to record harvests, understand weekly totals and keep your garden data close at hand.</Text><Text style={styles.introPoint}>✓ Save harvest records offline</Text><Text style={styles.introPoint}>✓ Track crops and weekly totals</Text><Text style={styles.introPoint}>✓ Import and export your data</Text><Pressable style={styles.start} onPress={async()=>{await AsyncStorage.setItem('ghr-onboarded','yes');setIntroDone(true);}}><Text style={styles.startText}>Get started</Text></Pressable></SafeAreaView>;

  const common={records:data.records,summary:data.summary};
  let screen;
  if(tab==='home') screen=<DashboardScreen {...common} weekly={data.weekly} onAdd={()=>setTab('add')} onRecords={()=>setTab('records')}/>;
  if(tab==='records') screen=<RecordsScreen records={data.records} onDelete={data.removeRecord} onEdit={record=>{setEditing(record);setTab('add');}}/>;
  if(tab==='add') screen=<AddHarvestScreen key={editing?.id || 'new'} initialRecord={editing} onCancel={()=>{setEditing(null);setTab('records');}} onSave={async input=>{const result=editing?await data.editRecord({...input,id:editing.id}):await data.addRecord(input);if(result.ok&&editing){setEditing(null);setTab('records');}return result;}}/>;
  if(tab==='insights') screen=<InsightsScreen {...common}/>;
  if(tab==='more') screen=<SettingsScreen onImport={importData} onExport={exportData} onDemo={loadDemo} onClear={clearAll} count={data.records.length}/>;

  return <SafeAreaView style={styles.root}>
    <StatusBar barStyle="dark-content" backgroundColor="#F4F7F1"/>
    <View style={styles.header}><Text style={styles.headerIcon}>🌱</Text><View style={{flex:1}}><Text style={styles.brand}>Garden Harvest Register</Text><Text style={styles.tagline}>RECORD · TRACK · GROW</Text></View><View style={[styles.dot,{backgroundColor:online?'#70A96B':'#D4A33D'}]}/></View>
    {data.error&&<Text style={styles.error}>{data.error}</Text>}
    <View style={{flex:1}}>{screen}</View>
    <View style={styles.nav}>{NAV.map(n=><Pressable key={n.key} onPress={()=>setTab(n.key)} style={styles.navItem}><Text style={[styles.navIcon,tab===n.key&&styles.navActive]}>{n.icon}</Text><Text style={[styles.navLabel,tab===n.key&&styles.navActive]}>{n.label}</Text></Pressable>)}</View>
  </SafeAreaView>;
}

export default function App(){return <SafeAreaProvider><AppContent/></SafeAreaProvider>;}

const styles=StyleSheet.create({
 root:{flex:1,backgroundColor:'#F4F7F1'},
 loading:{flex:1,backgroundColor:'#F4F7F1',alignItems:'center',justifyContent:'center'},
 brand:{fontSize:16,fontWeight:'900',color:'#153F2E'},muted:{color:'#718078',marginTop:8},
 header:{height:62,backgroundColor:'#fff',paddingHorizontal:16,flexDirection:'row',alignItems:'center',gap:10,borderBottomWidth:1,borderBottomColor:'#E1E9DF'},
 headerIcon:{fontSize:25},tagline:{fontSize:9,color:'#718078',letterSpacing:1.2,marginTop:3},dot:{width:9,height:9,borderRadius:5},
 nav:{height:65,backgroundColor:'#fff',borderTopWidth:1,borderTopColor:'#E1E9DF',flexDirection:'row',justifyContent:'space-around',alignItems:'center'},
 navItem:{alignItems:'center',flex:1},navIcon:{fontSize:20,color:'#718078'},navLabel:{fontSize:10,color:'#718078',marginTop:3,fontWeight:'700'},navActive:{color:'#28734D',fontWeight:'900'},
 intro:{flex:1,backgroundColor:'#F4F7F1',alignItems:'center',justifyContent:'center',padding:30},logo:{fontSize:58},introTitle:{fontSize:34,fontWeight:'900',color:'#153F2E',textAlign:'center',marginTop:15},introText:{fontSize:15,color:'#718078',textAlign:'center',lineHeight:23,marginVertical:18},introPoint:{alignSelf:'flex-start',color:'#20372A',fontWeight:'700',marginVertical:6},start:{backgroundColor:'#28734D',padding:16,borderRadius:14,alignSelf:'stretch',alignItems:'center',marginTop:22},startText:{color:'#fff',fontWeight:'900'},error:{color:'#B94C43',padding:10}
});
