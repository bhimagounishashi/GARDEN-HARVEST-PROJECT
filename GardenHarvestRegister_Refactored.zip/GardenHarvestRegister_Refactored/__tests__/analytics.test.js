import {
  averageQuantity, getExecutiveSummary, getTopCrop, getWeeklyTotals,
  groupByCrop, totalQuantity
} from '../src/utils/harvestAnalytics';

const sample = [
  { date:'2026-11-23', crop:'Tomato', qty:4 },
  { date:'2026-11-24', crop:'Tomato', qty:6 },
  { date:'2026-11-25', crop:'Spinach', qty:2 },
  { date:'2026-11-16', crop:'Carrot', qty:8 }
];

describe('harvest analytics', () => {
  test('calculates total and average quantity', () => {
    expect(totalQuantity(sample)).toBe(20);
    expect(averageQuantity(sample)).toBe(5);
  });
  test('groups records by crop', () => {
    expect(groupByCrop(sample)).toEqual({ Tomato:10, Spinach:2, Carrot:8 });
  });
  test('returns the highest yielding crop', () => {
    expect(getTopCrop(sample)).toEqual(['Tomato',10]);
  });
  test('calculates Monday to Sunday weekly totals', () => {
    const result=getWeeklyTotals(sample,'2026-11-25');
    expect(result.start).toBe('2026-11-23');
    expect(result.end).toBe('2026-11-29');
    expect(result.total).toBe(12);
  });
  test('returns zero-safe executive summary for empty data', () => {
    expect(getExecutiveSummary([])).toEqual({
      total:0,average:0,count:0,cropCount:0,highest:0,lowest:0,topCrop:null
    });
  });
});
