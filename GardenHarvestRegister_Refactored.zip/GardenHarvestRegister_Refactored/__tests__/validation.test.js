import { isValidISODate, validateHarvest } from '../src/utils/validation';

const valid = { crop:'Tomato', category:'Fruit', qty:'4.5', date:'2026-11-20' };

describe('harvest validation', () => {
  test('accepts a valid harvest entry', () => {
    expect(validateHarvest(valid,'2026-11-25')).toEqual({});
  });
  test('rejects blank crop names', () => {
    expect(validateHarvest({...valid,crop:' '},'2026-11-25')).toHaveProperty('crop');
  });
  test('rejects zero, negative and excessive quantities', () => {
    expect(validateHarvest({...valid,qty:'0'},'2026-11-25')).toHaveProperty('qty');
    expect(validateHarvest({...valid,qty:'-2'},'2026-11-25')).toHaveProperty('qty');
    expect(validateHarvest({...valid,qty:'1001'},'2026-11-25')).toHaveProperty('qty');
  });
  test('rejects invalid and future dates', () => {
    expect(isValidISODate('2026-02-30')).toBe(false);
    expect(validateHarvest({...valid,date:'2026-11-26'},'2026-11-25')).toHaveProperty('date');
  });
});
