# Garden Harvest Register — Refactored Native App

**Project #67 · Everyday Innovators · Food & Agriculture**

This refactored Expo / React Native application separates the interface, data layer, business logic, validation, CSV processing and logging. It is a native mobile application, not a WebView and not an HTML/CSS website.

## What changed to address the evaluation feedback

| Evaluation feedback | Implemented improvement |
|---|---|
| No automated tests | Jest + jest-expo tests for analytics and validation |
| Monolithic App.js | Split into screens, reusable UI components, hook, utilities and services |
| No data access separation | SQLite repository in `src/data/harvestRepository.js` |
| Manual CSV parsing | Papa Parse library in `src/utils/csv.js` |
| No logging service | Centralized structured logger in `src/services/logger.js` |
| Business logic mixed with UI | Pure analytics and validation modules, plus `useHarvestData` custom hook |

## Features

- Dashboard totals, entry count, average, crop count and weekly summary
- Add and validate harvest records
- Search and category filtering
- Edit and delete records
- Weekly Monday–Sunday analytics
- Crop totals and executive summary
- SQLite local persistence
- CSV and JSON import
- CSV, JSON and Markdown export
- Offline-first operation and connectivity indicator
- On-device data; no login or cloud service required

## Project structure

```text
GardenHarvestRegister/
├── App.js
├── app.json
├── babel.config.js
├── package.json
├── README.md
├── __tests__/
│   ├── analytics.test.js
│   └── validation.test.js
└── src/
    ├── components/
    │   └── UI.js
    ├── data/
    │   └── harvestRepository.js
    ├── hooks/
    │   └── useHarvestData.js
    ├── screens/
    │   ├── AddHarvestScreen.js
    │   ├── DashboardScreen.js
    │   ├── InsightsScreen.js
    │   ├── RecordsScreen.js
    │   └── SettingsScreen.js
    ├── services/
    │   └── logger.js
    └── utils/
        ├── csv.js
        ├── harvestAnalytics.js
        └── validation.js
```

## Run the app

Install Node.js LTS and open this folder in VS Code.

```bash
npm install
npx expo start
```

Install Expo Go on an Android/iOS device and scan the QR code.

## Run automated tests

```bash
npm test
```

Run the test suite in watch mode:

```bash
npm run test:watch
```

The tests cover totals, averages, crop aggregation, top crop, week boundaries, empty datasets and input validation. Tests are included in the ZIP; run them after installing dependencies.

## Android APK

```bash
npm install
npm install --global eas-cli
eas login
eas build:configure
eas build --platform android --profile preview
```

For a local installable APK, add or retain an EAS preview profile with `android.buildType` set to `apk` in `eas.json`.

## Important notes

- SQLite is the persistence layer and records stay on the device.
- CSV import uses Papa Parse, including quoted values and commas inside fields.
- The logger emits structured JSON messages to the development console. A production log aggregation backend is not configured.
- This is source code for an Expo app, not a prebuilt APK. Android/iOS builds require the commands above and the relevant build environment/account.
