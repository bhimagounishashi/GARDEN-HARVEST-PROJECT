export const CATEGORIES = ['Fruit', 'Leafy', 'Root', 'Other'];
export const MAX_QUANTITY_KG = 1000;

export function isValidISODate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(value || ''))) return false;
  const date = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

export function validateHarvest(input, today = new Date().toISOString().slice(0, 10)) {
  const errors = {};
  const crop = String(input.crop || '').trim();
  const quantity = Number(input.qty);
  if (!crop) errors.crop = 'Crop name is required.';
  else if (crop.length > 45) errors.crop = 'Crop name must be 45 characters or fewer.';
  if (!Number.isFinite(quantity) || quantity <= 0) errors.qty = 'Quantity must be a number greater than zero.';
  else if (quantity > MAX_QUANTITY_KG) errors.qty = `Quantity cannot exceed ${MAX_QUANTITY_KG} kg.`;
  if (!isValidISODate(input.date)) errors.date = 'Enter a valid date in YYYY-MM-DD format.';
  else if (input.date > today) errors.date = 'Harvest date cannot be in the future.';
  if (!CATEGORIES.includes(input.category)) errors.category = 'Choose a valid category.';
  return errors;
}
