export function totalQuantity(records = []) {
  return records.reduce((sum, record) => sum + Number(record.qty || 0), 0);
}

export function averageQuantity(records = []) {
  return records.length ? totalQuantity(records) / records.length : 0;
}

export function groupByCrop(records = []) {
  return records.reduce((groups, record) => {
    const key = record.crop || 'Unknown';
    groups[key] = (groups[key] || 0) + Number(record.qty || 0);
    return groups;
  }, {});
}

export function getTopCrop(records = []) {
  const entries = Object.entries(groupByCrop(records));
  if (!entries.length) return null;
  return entries.sort((a, b) => b[1] - a[1])[0];
}

export function getWeekRange(dateString) {
  const date = new Date(`${dateString}T12:00:00`);
  if (Number.isNaN(date.getTime())) throw new Error('Invalid date');
  const day = (date.getDay() + 6) % 7;
  date.setDate(date.getDate() - day);
  const start = new Date(date);
  const end = new Date(date);
  end.setDate(end.getDate() + 6);
  const format = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  return { start: format(start), end: format(end) };
}

export function getWeeklyTotals(records = [], dateString = new Date().toISOString().slice(0,10)) {
  const { start, end } = getWeekRange(dateString);
  const selected = records.filter(r => r.date >= start && r.date <= end);
  const byCrop = groupByCrop(selected);
  return {
    start, end, records: selected,
    total: totalQuantity(selected),
    byCrop
  };
}

export function getExecutiveSummary(records = []) {
  const quantities = records.map(r => Number(r.qty || 0));
  return {
    total: totalQuantity(records),
    average: averageQuantity(records),
    count: records.length,
    cropCount: new Set(records.map(r => r.crop)).size,
    highest: quantities.length ? Math.max(...quantities) : 0,
    lowest: quantities.length ? Math.min(...quantities) : 0,
    topCrop: getTopCrop(records)
  };
}
