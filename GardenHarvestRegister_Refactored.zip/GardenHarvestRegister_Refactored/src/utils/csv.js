import Papa from 'papaparse';

export function parseHarvestCsv(text) {
  const parsed = Papa.parse(text, {
    header: true, skipEmptyLines: 'greedy', transformHeader: h => h.trim()
  });
  if (parsed.errors.length) {
    return { rows: parsed.data, errors: parsed.errors.map(e => e.message) };
  }
  return { rows: parsed.data, errors: [] };
}

export function stringifyHarvestCsv(records) {
  return Papa.unparse(records.map(r => ({
    date: r.date, crop: r.crop, category: r.category, quantity_kg: r.qty
  })));
}
