import React from 'react';
import { Pressable, Text, TextInput, View, StyleSheet } from 'react-native';

export const palette = {
  bg: '#F4F7F1', surface: '#FFFFFF', ink: '#20372A', muted: '#718078',
  green: '#28734D', forest: '#153F2E', line: '#E1E9DF', danger: '#B94C43',
  pale: '#EAF3E9', gold: '#9B711E'
};

export function Screen({ title, subtitle, children }) {
  return <View style={styles.screen}>
    <Text style={styles.title}>{title}</Text>
    {!!subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
    {children}
  </View>;
}
export function Card({ children }) {
  return <View style={styles.card}>{children}</View>;
}
export function Metric({ label, value, caption }) {
  return <View style={styles.metric}>
    <Text style={styles.metricLabel}>{label}</Text>
    <Text style={styles.metricValue} numberOfLines={1}>{value}</Text>
    {!!caption && <Text style={styles.caption}>{caption}</Text>}
  </View>;
}
export function ActionButton({ title, onPress, secondary = false, danger = false }) {
  return <Pressable onPress={onPress} style={[styles.button, secondary && styles.secondary, danger && styles.danger]}>
    <Text style={[styles.buttonText, secondary && styles.secondaryText]}>{title}</Text>
  </Pressable>;
}
export function Field({ label, value, onChangeText, placeholder, keyboardType, error }) {
  return <View style={styles.field}>
    <Text style={styles.label}>{label}</Text>
    <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder}
      keyboardType={keyboardType} placeholderTextColor="#89968D"
      style={[styles.input, !!error && { borderColor: palette.danger }]} />
    {!!error && <Text style={styles.error}>{error}</Text>}
  </View>;
}
const styles = StyleSheet.create({
  screen:{flex:1,backgroundColor:palette.bg,padding:18},
  title:{fontSize:27,fontWeight:'800',color:palette.forest},
  subtitle:{fontSize:14,color:palette.muted,marginTop:5,marginBottom:18},
  card:{backgroundColor:palette.surface,borderRadius:18,padding:16,marginBottom:14,borderWidth:1,borderColor:palette.line},
  metric:{backgroundColor:palette.surface,borderRadius:16,padding:14,flex:1,minWidth:'45%',borderWidth:1,borderColor:palette.line},
  metricLabel:{fontSize:10,fontWeight:'800',color:palette.muted,letterSpacing:.6},
  metricValue:{fontSize:22,fontWeight:'800',color:palette.forest,marginTop:8},
  caption:{fontSize:11,color:palette.muted,marginTop:4},
  button:{backgroundColor:palette.green,borderRadius:12,padding:14,alignItems:'center',marginVertical:6},
  buttonText:{color:'#fff',fontWeight:'800'},
  secondary:{backgroundColor:palette.pale},
  secondaryText:{color:palette.forest},
  danger:{backgroundColor:palette.danger},
  field:{marginBottom:14},
  label:{fontSize:11,fontWeight:'800',color:palette.muted,marginBottom:7},
  input:{borderWidth:1,borderColor:palette.line,backgroundColor:'#fff',borderRadius:11,padding:12,color:palette.ink},
  error:{color:palette.danger,fontSize:12,marginTop:5}
});
