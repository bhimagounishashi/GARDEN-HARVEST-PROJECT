const LEVELS = { info: 'INFO', warn: 'WARN', error: 'ERROR' };

function write(level, message, details) {
  const entry = {
    timestamp: new Date().toISOString(),
    level: LEVELS[level] || 'INFO',
    message: String(message),
    details: details ? String(details?.stack || details) : undefined
  };
  const output = JSON.stringify(entry);
  if (level === 'error') console.error(output);
  else if (level === 'warn') console.warn(output);
  else console.info(output);
  return entry;
}

export const logger = {
  info: (message, details) => write('info', message, details),
  warn: (message, details) => write('warn', message, details),
  error: (message, details) => write('error', message, details)
};
