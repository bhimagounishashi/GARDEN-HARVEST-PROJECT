import React from 'react';
import { ScrollView, Text, View, StyleSheet } from 'react-native';
import { ActionButton, Card, Metric, palette, Screen } from '../components/UI';

export default function DashboardScreen({ records, summary, weekly, onAdd, onRecords }) {
  const week = weekly(new Date().toISOString().slice(0,10));
  const top = Object.entries(week.byCrop).sort((a,b)=>b[1]-a[1]).slice(0,5);
  return <Screen title="Garden overview" subtitle="Your harvest, in clear numbers.">
    <ScrollView showsVerticalScrollIndicator={false}>
      <View style={s.grid}>
        <Metric label="TOTAL HARVEST" value={`${summary.total.toFixed(1)} kg`} caption="All saved records"/>
        <Metric label="ENTRIES" value={String(summary.count)} caption="Harvest records"/>
        <Metric label="AVERAGE / ENTRY" value={`${summary.average.toFixed(1)} kg`} caption="Mean quantity"/>
        <Metric label="DIFFERENT CROPS" value={String(summary.cropCount)} caption="Crop varieties"/>
      </View>
      <ActionButton title="＋ Add harvest" onPress={onAdd}/>
      <Card>
        <Text style={s.heading}>This week</Text>
        <Text style={s.total}>{week.total.toFixed(2)} kg</Text>
        <Text style={s.muted}>{week.start} — {week.end}</Text>
        {top.map(([crop, qty])=><View key={crop} style={s.row}><Text style={s.crop}>{crop}</Text><Text style={s.qty}>{qty.toFixed(1)} kg</Text></View>)}
        {!top.length && <Text style={s.muted}>No harvests recorded this week.</Text>}
      </Card>
      <Card>
        <Text style={s.heading}>Recent harvests</Text>
        {records.slice(0,5).map(r=><View key={r.id} style={s.row}><View><Text style={s.crop}>{r.crop}</Text><Text style={s.muted}>{r.date} · {r.category}</Text></View><Text style={s.qty}>{Number(r.qty).toFixed(1)} kg</Text></View>)}
        {!records.length && <Text style={s.muted}>Your first harvest will appear here.</Text>}
        <ActionButton title="View all records" secondary onPress={onRecords}/>
      </Card>
      {records.some(r=>Number(r.qty)>500) && <Text style={s.alert}>⚠ Review unusually large entries above 500 kg.</Text>}
    </ScrollView>
  </Screen>;
}
const s=StyleSheet.create({grid:{flexDirection:'row',flexWrap:'wrap',gap:10,marginBottom:12},heading:{fontSize:17,fontWeight:'800',color:palette.forest,marginBottom:8},total:{fontSize:30,fontWeight:'900',color:palette.green},muted:{color:palette.muted,fontSize:12,marginTop:3},row:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',paddingVertical:11,borderBottomWidth:1,borderBottomColor:palette.line},crop:{fontWeight:'700',color:palette.ink},qty:{fontWeight:'800',color:palette.green},alert:{color:palette.gold,fontWeight:'700',padding:12}});
