import React, { useState } from 'react';
import { ScrollView, Text, View, Pressable, StyleSheet } from 'react-native';
import { ActionButton, Card, Field, palette, Screen } from '../components/UI';
import { CATEGORIES } from '../utils/validation';

export default function AddHarvestScreen({ onSave, initialRecord, onCancel }) {
  const today = new Date().toISOString().slice(0,10);
  const [crop,setCrop]=useState(initialRecord?.crop || ''); const [category,setCategory]=useState(initialRecord?.category || 'Fruit');
  const [qty,setQty]=useState(initialRecord ? String(initialRecord.qty) : ''); const [date,setDate]=useState(initialRecord?.date || today); const [errors,setErrors]=useState({});
  const submit=async()=>{const result=await onSave({crop,category,qty,date});setErrors(result.errors||{});if(result.ok&&!initialRecord){setCrop('');setQty('');setDate(today);setErrors({});}};
  return <Screen title={initialRecord ? "Edit harvest" : "Add a harvest"} subtitle="Capture a harvest entry accurately.">
    <ScrollView keyboardShouldPersistTaps="handled">
      <Card>
        <Field label="CROP NAME" value={crop} onChangeText={setCrop} placeholder="e.g. Tomato" error={errors.crop}/>
        <Text style={s.label}>CATEGORY</Text>
        <View style={s.chips}>{CATEGORIES.map(x=><Pressable key={x} onPress={()=>setCategory(x)} style={[s.chip,category===x&&s.active]}><Text style={{color:category===x?'#fff':palette.forest,fontWeight:'700'}}>{x}</Text></Pressable>)}</View>
        <Field label="QUANTITY (KG)" value={qty} onChangeText={setQty} placeholder="e.g. 5.5" keyboardType="decimal-pad" error={errors.qty}/>
        <Field label="HARVEST DATE (YYYY-MM-DD)" value={date} onChangeText={setDate} placeholder="YYYY-MM-DD" error={errors.date}/>
        {!!errors.category&&<Text style={s.error}>{errors.category}</Text>}
        {!!errors.form&&<Text style={s.error}>{errors.form}</Text>}
        <Text style={s.hint}>Quantity must be greater than 0 and no more than 1,000 kg.</Text>
        {onCancel&&<ActionButton title="Cancel" secondary onPress={onCancel}/>}<ActionButton title={initialRecord ? "Save changes" : "Save harvest record"} onPress={submit}/>
      </Card>
    </ScrollView>
  </Screen>;
}
const s=StyleSheet.create({label:{fontSize:11,fontWeight:'800',color:palette.muted,marginBottom:8},chips:{flexDirection:'row',flexWrap:'wrap',gap:8,marginBottom:15},chip:{borderRadius:20,borderWidth:1,borderColor:palette.line,paddingVertical:9,paddingHorizontal:13},active:{backgroundColor:palette.green,borderColor:palette.green},hint:{fontSize:12,color:palette.muted,marginBottom:10},error:{color:palette.danger,marginBottom:8}});
