import React, { useMemo, useState } from 'react';
import { Alert, FlatList, Pressable, Text, TextInput, View, StyleSheet } from 'react-native';
import { ActionButton, Card, palette, Screen } from '../components/UI';
import { CATEGORIES } from '../utils/validation';

export default function RecordsScreen({ records, onDelete, onEdit }) {
  const [search,setSearch]=useState(''); const [filter,setFilter]=useState('All');
  const filtered=useMemo(()=>records.filter(r=>(filter==='All'||r.category===filter)&&`${r.crop} ${r.category}`.toLowerCase().includes(search.toLowerCase())),[records,filter,search]);
  const remove=id=>Alert.alert('Delete harvest?','This record will be permanently removed.',[{text:'Cancel',style:'cancel'},{text:'Delete',style:'destructive',onPress:()=>onDelete(id)}]);
  return <Screen title="Harvest records" subtitle="Search, filter and manage saved entries.">
    <TextInput value={search} onChangeText={setSearch} placeholder="Search crop or category…" placeholderTextColor={palette.muted} style={s.search}/>
    <View style={s.filters}>{['All',...CATEGORIES].map(x=><Pressable key={x} onPress={()=>setFilter(x)} style={[s.filter,filter===x&&s.selected]}><Text style={{color:filter===x?'#fff':palette.forest,fontWeight:'700'}}>{x}</Text></Pressable>)}</View>
    <Text style={s.count}>{filtered.length} record(s)</Text>
    <FlatList data={filtered} keyExtractor={r=>r.id} contentContainerStyle={{paddingBottom:25}} renderItem={({item})=><Card>
      <View style={s.record}><View style={{flex:1}}><Text style={s.crop}>{item.crop}</Text><Text style={s.muted}>{item.date} · {item.category}</Text><Text style={s.qty}>{Number(item.qty).toFixed(2)} kg</Text></View>
      <View><Pressable onPress={()=>onEdit(item)} style={s.action}><Text style={s.actionText}>Edit</Text></Pressable><Pressable onPress={()=>remove(item.id)} style={[s.action,{backgroundColor:'#FFF0ED'}]}><Text style={[s.actionText,{color:palette.danger}]}>Delete</Text></Pressable></View></View>
    </Card>} ListEmptyComponent={<Text style={s.empty}>No records found. Add a harvest or adjust your search.</Text>}/>
  </Screen>;
}
const s=StyleSheet.create({search:{backgroundColor:'#fff',borderWidth:1,borderColor:palette.line,borderRadius:12,padding:13,color:palette.ink},filters:{flexDirection:'row',flexWrap:'wrap',gap:7,marginVertical:12},filter:{borderWidth:1,borderColor:palette.line,borderRadius:18,paddingHorizontal:11,paddingVertical:8},selected:{backgroundColor:palette.green,borderColor:palette.green},count:{fontSize:12,color:palette.muted,marginBottom:10},record:{flexDirection:'row',alignItems:'center'},crop:{fontSize:17,fontWeight:'800',color:palette.ink},muted:{color:palette.muted,fontSize:12,marginTop:4},qty:{fontWeight:'800',color:palette.green,marginTop:8},action:{paddingHorizontal:12,paddingVertical:8,backgroundColor:palette.pale,borderRadius:9,marginVertical:3},actionText:{color:palette.forest,fontWeight:'800',fontSize:12},empty:{color:palette.muted,textAlign:'center',padding:30}});
