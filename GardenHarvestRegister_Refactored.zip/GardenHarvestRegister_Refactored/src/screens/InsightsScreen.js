import React, { useMemo, useState } from 'react';
import { ScrollView, Text, View, StyleSheet } from 'react-native';
import { Card, Metric, palette, Screen, Field } from '../components/UI';
import { groupByCrop, getWeeklyTotals } from '../utils/harvestAnalytics';

export default function InsightsScreen({ records, summary }) {
  const [date,setDate]=useState(new Date().toISOString().slice(0,10));
  const weekly=useMemo(()=>{try{return getWeeklyTotals(records,date)}catch{return {start:'—',end:'—',total:0,byCrop:{}}}},[records,date]);
  const crops=Object.entries(groupByCrop(records)).sort((a,b)=>b[1]-a[1]).slice(0,7);
  const max=Math.max(1,...crops.map(x=>x[1]));
  return <Screen title="Executive summary" subtitle="Harvest performance and weekly trends.">
    <ScrollView>
      <View style={s.grid}>
        <Metric label="HIGHEST ENTRY" value={`${summary.highest.toFixed(1)} kg`}/>
        <Metric label="LOWEST ENTRY" value={`${summary.lowest.toFixed(1)} kg`}/>
        <Metric label="TOTAL HARVEST" value={`${summary.total.toFixed(1)} kg`}/>
        <Metric label="AVERAGE" value={`${summary.average.toFixed(1)} kg`}/>
      </View>
      <Card><Text style={s.heading}>Harvest by crop</Text>{crops.map(([name,value])=><View key={name} style={s.barRow}><View style={s.barHeader}><Text style={s.crop}>{name}</Text><Text style={s.crop}>{value.toFixed(1)} kg</Text></View><View style={s.track}><View style={[s.fill,{width:`${value/max*100}%`}/></View></View>)}{!crops.length&&<Text style={s.muted}>No harvest data yet.</Text>}</Card>
      <Card><Text style={s.heading}>Weekly harvest totals</Text><Field label="SELECT A DATE (YYYY-MM-DD)" value={date} onChangeText={setDate} placeholder="YYYY-MM-DD"/><Text style={s.range}>{weekly.start} — {weekly.end}</Text><Text style={s.total}>{weekly.total.toFixed(2)} kg</Text>{Object.entries(weekly.byCrop).sort((a,b)=>b[1]-a[1]).map(([name,value])=><View key={name} style={s.line}><Text style={s.crop}>{name}</Text><Text style={s.crop}>{value.toFixed(2)} kg</Text></View>)}</Card>
    </ScrollView>
  </Screen>;
}
const s=StyleSheet.create({grid:{flexDirection:'row',flexWrap:'wrap',gap:10,marginBottom:12},heading:{fontSize:17,fontWeight:'800',color:palette.forest,marginBottom:12},barRow:{marginBottom:13},barHeader:{flexDirection:'row',justifyContent:'space-between',marginBottom:6},crop:{color:palette.ink,fontWeight:'700'},track:{height:9,backgroundColor:palette.pale,borderRadius:10,overflow:'hidden'},fill:{height:9,backgroundColor:palette.green,borderRadius:10},muted:{color:palette.muted},range:{color:palette.muted,marginBottom:8},total:{fontSize:27,fontWeight:'900',color:palette.green,marginBottom:8},line:{flexDirection:'row',justifyContent:'space-between',paddingVertical:9,borderBottomWidth:1,borderBottomColor:palette.line}});
