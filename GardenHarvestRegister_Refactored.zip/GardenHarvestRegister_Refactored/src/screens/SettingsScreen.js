import React from 'react';
import { Alert, Text } from 'react-native';
import { Card, ActionButton, palette, Screen } from '../components/UI';

export default function SettingsScreen({ onImport, onExport, onDemo, onClear, count }) {
  return <Screen title="More & settings" subtitle="Manage your harvest data.">
    <Card><Text style={{fontSize:17,fontWeight:'800',color:palette.forest}}>Data management</Text><Text style={{color:palette.muted,lineHeight:20,marginVertical:10}}>Your harvest records are stored in a private SQLite database on this device. Import and export files whenever needed.</Text>
      <ActionButton title="Import CSV" onPress={()=>onImport('csv')} secondary/>
      <ActionButton title="Import JSON" onPress={()=>onImport('json')} secondary/>
      <ActionButton title="Export CSV" onPress={()=>onExport('csv')} secondary/>
      <ActionButton title="Export JSON" onPress={()=>onExport('json')} secondary/>
      <ActionButton title="Export Markdown report" onPress={()=>onExport('md')} secondary/>
      <ActionButton title="Load 40 demo records" onPress={onDemo} secondary/>
      <ActionButton title={`Clear all ${count} records`} danger onPress={()=>Alert.alert('Clear all records?','This cannot be undone.',[{text:'Cancel',style:'cancel'},{text:'Clear',style:'destructive',onPress:onClear}])}/>
    </Card>
    <Card><Text style={{fontSize:17,fontWeight:'800',color:palette.forest}}>About this project</Text><Text style={{color:palette.muted,marginTop:8,lineHeight:21}}>Everyday Innovators · Project #67{"\n"}Food & Agriculture{"\n"}Garden Harvest Register · Record · Track · Grow</Text></Card>
  </Screen>;
}
