import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  deleteHarvest, getAllHarvests, insertHarvest, openHarvestDatabase,
  replaceAllHarvests, updateHarvest
} from '../data/harvestRepository';
import { logger } from '../services/logger';
import { getExecutiveSummary, getWeeklyTotals } from '../utils/harvestAnalytics';
import { validateHarvest } from '../utils/validation';

const makeId = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`;

export function useHarvestData() {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const refresh = useCallback(async () => {
    try {
      const rows = await getAllHarvests();
      setRecords(rows);
      setError(null);
    } catch (err) {
      logger.error('Unable to load harvest records', err);
      setError('Could not load saved harvest records.');
      throw err;
    }
  }, []);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        await openHarvestDatabase();
        const rows = await getAllHarvests();
        if (active) setRecords(rows);
      } catch (err) {
        logger.error('Database initialization failed', err);
        if (active) setError('Database initialization failed. Please restart the app.');
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => { active = false; };
  }, []);

  const addRecord = useCallback(async input => {
    const validation = validateHarvest(input);
    if (Object.keys(validation).length) return { ok: false, errors: validation };
    try {
      const record = {
        id: makeId(), date: input.date, crop: input.crop.trim(),
        category: input.category, qty: Number(input.qty),
        created_at: new Date().toISOString()
      };
      await insertHarvest(record);
      await refresh();
      logger.info('Harvest record created', record.id);
      return { ok: true, record };
    } catch (err) {
      logger.error('Could not create harvest record', err);
      return { ok: false, errors: { form: 'Could not save this record.' } };
    }
  }, [refresh]);

  const editRecord = useCallback(async input => {
    const validation = validateHarvest(input);
    if (Object.keys(validation).length) return { ok: false, errors: validation };
    try {
      await updateHarvest({ ...input, crop: input.crop.trim(), qty: Number(input.qty) });
      await refresh();
      logger.info('Harvest record updated', input.id);
      return { ok: true };
    } catch (err) {
      logger.error('Could not update harvest record', err);
      return { ok: false, errors: { form: 'Could not update this record.' } };
    }
  }, [refresh]);

  const removeRecord = useCallback(async id => {
    try {
      await deleteHarvest(id);
      await refresh();
      logger.info('Harvest record deleted', id);
      return true;
    } catch (err) {
      logger.error('Could not delete harvest record', err);
      return false;
    }
  }, [refresh]);

  const importRecords = useCallback(async incoming => {
    const valid = [];
    const errors = [];
    incoming.forEach((record, index) => {
      const normalized = {
        id: makeId(),
        date: String(record.date || record.harvest_date || ''),
        crop: String(record.crop || '').trim(),
        category: String(record.category || 'Other'),
        qty: Number(record.qty ?? record.quantity_kg ?? record.quantity),
        created_at: new Date().toISOString()
      };
      const validation = validateHarvest(normalized);
      if (Object.keys(validation).length) errors.push({ row: index + 1, errors: validation });
      else valid.push(normalized);
    });
    if (valid.length) {
      try {
        const existingIds = new Set(records.map(r => `${r.date}|${r.crop}|${r.qty}`));
        const merged = [...records, ...valid.filter(r => !existingIds.has(`${r.date}|${r.crop}|${r.qty}`))];
        await replaceAllHarvests(merged);
        await refresh();
      } catch (err) {
        logger.error('Import failed during database write', err);
        return { imported: 0, errors: [...errors, { row: 0, errors: { form: 'Database import failed.' } }] };
      }
    }
    logger.info('Harvest import completed', `${valid.length} valid row(s)`);
    return { imported: valid.length, errors };
  }, [records, refresh]);

  const summary = useMemo(() => getExecutiveSummary(records), [records]);
  const weekly = useCallback(date => getWeeklyTotals(records, date), [records]);

  return { records, loading, error, summary, weekly, addRecord, editRecord, removeRecord, importRecords, refresh };
}
