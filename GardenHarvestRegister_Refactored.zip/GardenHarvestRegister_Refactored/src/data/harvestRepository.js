import * as SQLite from 'expo-sqlite';
import { logger } from '../services/logger';

let database;

export async function openHarvestDatabase() {
  if (database) return database;
  database = await SQLite.openDatabaseAsync('garden-harvest.db');
  await database.execAsync(`
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS harvests (
      id TEXT PRIMARY KEY NOT NULL,
      date TEXT NOT NULL,
      crop TEXT NOT NULL,
      category TEXT NOT NULL,
      qty REAL NOT NULL CHECK(qty > 0 AND qty <= 1000),
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_harvest_date ON harvests(date);
    CREATE INDEX IF NOT EXISTS idx_harvest_crop ON harvests(crop);
  `);
  logger.info('Harvest database initialized');
  return database;
}

export async function getAllHarvests() {
  const db = await openHarvestDatabase();
  return db.getAllAsync('SELECT * FROM harvests ORDER BY date DESC, created_at DESC');
}

export async function insertHarvest(record) {
  const db = await openHarvestDatabase();
  await db.runAsync(
    'INSERT INTO harvests (id,date,crop,category,qty,created_at) VALUES (?,?,?,?,?,?)',
    [record.id, record.date, record.crop, record.category, record.qty, record.created_at || new Date().toISOString()]
  );
  return record;
}

export async function updateHarvest(record) {
  const db = await openHarvestDatabase();
  await db.runAsync(
    'UPDATE harvests SET date=?, crop=?, category=?, qty=? WHERE id=?',
    [record.date, record.crop, record.category, record.qty, record.id]
  );
  return record;
}

export async function deleteHarvest(id) {
  const db = await openHarvestDatabase();
  await db.runAsync('DELETE FROM harvests WHERE id=?', [id]);
}

export async function replaceAllHarvests(records) {
  const db = await openHarvestDatabase();
  await db.withTransactionAsync(async () => {
    await db.runAsync('DELETE FROM harvests');
    for (const record of records) {
      await db.runAsync(
        'INSERT INTO harvests (id,date,crop,category,qty,created_at) VALUES (?,?,?,?,?,?)',
        [record.id, record.date, record.crop, record.category, record.qty, record.created_at || new Date().toISOString()]
      );
    }
  });
}

export async function closeHarvestDatabase() {
  if (database) {
    await database.closeAsync();
    database = undefined;
  }
}
